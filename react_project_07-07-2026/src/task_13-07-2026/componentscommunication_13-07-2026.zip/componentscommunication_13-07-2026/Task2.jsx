


function Child({ text }) {
  return <h1>{text}</h1>;
}

export default Child;

